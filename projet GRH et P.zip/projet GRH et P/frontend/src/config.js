// Configuration de l'application
export const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000/api"
export const SOCKET_URL = process.env.REACT_APP_SOCKET_URL || "http://localhost:5000"
export const APP_NAME = "Système de Gestion RH"
